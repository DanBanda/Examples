﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PruebaMicroservicios.BE
{
    public class Persona
    {
        public string Nombre { get; set; }
        public char Genero { get; set; }
        public int Edad { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
    }
}