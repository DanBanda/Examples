﻿using PruebaMicroservicios.BE;
using System;
using System.Collections.Generic;
using System.Text;

namespace PruebaMicroservicios.DAL.Interfaces
{
    public interface IMovimientoCRUD
    {
        IEnumerable<Movimiento> GetAll();
        ResultadoMovimiento GetByIdMovimiento(int idMovimiento);
        ResultadoMovimiento Add(Movimiento movimiento);
        ResultadoMovimiento Delete(int idMovimiento);
        ResultadoMovimiento Update(Movimiento movimiento);
    }
}